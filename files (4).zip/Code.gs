/** TWELVOLNA.EIGHTHEREALIS - Kelas 12.8 SMAN 1 Kota Sukabumi | EIGHT ENERGY, BIG SINERGY */
var SS_ID = '1JZs-wqZCauijupgefHUWcyGkHfcenekx2rSesZECrIU';
var TZ = 'Asia/Jakarta';
var KELAS = '12.8';
var F_BUKTI = 'BUKTI_PIKET_TWELVOLNA';
var F_PROFIL = 'PROFILE_TWELVOLNA';
var F_AGENDA = 'AGENDA_TWELVOLNA';
var HARI = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
var H = {
  Siswa: ['Username', 'Password', 'Nama', 'Kelas', 'Role', 'Aktif'],
  Guru: ['Username', 'Password', 'Nama', 'Role', 'Aktif'],
  JadwalPiket: ['Hari', 'Username', 'Nama'],
  JadwalPelajaran: ['Hari', 'Jam', 'Mapel'],
  Absensi: ['Timestamp', 'Tanggal', 'Hari', 'Username', 'Nama', 'Kelas', 'Status', 'Alasan'],
  Piket: ['Timestamp', 'Tanggal', 'Hari', 'Username', 'Nama', 'Kelas', 'Status', 'Keterangan', 'FotoURL', 'FotoID'],
  Profil: ['Username', 'Nama', 'FotoURL', 'FotoID', 'Updated'],
  Pengumuman: ['Timestamp', 'Tanggal', 'Isi', 'Oleh'],
  KasKeluar: ['ID', 'Tanggal', 'Keperluan', 'Jumlah', 'Catatan', 'Status', 'Oleh', 'UpdatedAt', 'Kategori'],
  Kas: ['ID', 'Tanggal', 'Bulan', 'Tahun', 'Username', 'Nama', 'NominalWajib', 'NominalBayar', 'Kekurangan', 'Status', 'Catatan', 'UpdatedAt', 'UpdatedBy'],
  Agenda: ['Timestamp', 'Tanggal', 'Jenis', 'Judul', 'Catatan', 'Oleh', 'FotoID'],
  Polling: ['ID', 'Timestamp', 'Pertanyaan', 'Opsi', 'Status', 'Oleh'],
  Suara: ['PollID', 'Username', 'Pilihan', 'Timestamp'],
  Apresiasi: ['Timestamp', 'Dari', 'Untuk', 'Pesan'],
  Saran: ['Timestamp', 'Tanggal', 'Isi', 'Dari'],
  SaranLog: ['Bulan', 'Kode'],
  Perangkat: ['Username', 'Token', 'Updated']
};
// [nama singkat (= username), nama lengkap]
var JADWAL = {
  Senin: [['Rafael', 'M. Rafael Al Fatah'], ['Fiqri', 'Fiqri Imamul Hidayah'], ['Hilda', 'Hilda Aulia'], ['Afwa', 'Afwa Rukhaniah Amijaya'], ['Yanesa', 'Yanesa Agustina'], ['Marsela', 'Marsela Eka Cahyani'], ['Yolanda', 'Yolanda Putri Utami']],
  Selasa: [['Khailan', 'Muhammad Khailan Alividi'], ['Ikhsan', 'Ikhsan Kamil Muharam Nugraha'], ['Tias', 'Tias Kamil'], ['Zefanya', 'Zefanya Akira Yumna'], ['Freedella', 'Freedella Jacinda Hilman'], ['Adzra', 'Adzra Dwi Ginanjar'], ['Nadia', 'Nadia Isaura Fajriah']],
  Rabu: [['Daffa', 'Muhamad Daffa Alwy Henryansyah'], ['Davin', 'Davin Alvino'], ['Salma', 'Salma Aulia Nur Insani'], ['Aura', 'Aura Nathania Putri Jatnika'], ['Alya', 'Alya Alifia Husada'], ['Kanza', 'Kanza Almyra Irawanda'], ['Adinda', 'Adinda Putri Ilmi Syakina'], ['Khanaya', 'Khanaya Aghita Hermanto']],
  Kamis: [['Andrea', 'Andrea Julian Alif Fadillah'], ['Ahmad', 'Ahmad Feriansyah'], ['Ali', 'M. Abdul Muta Ali'], ['Ratu', 'Ratu Ayu Pratiwi'], ['Tsani', 'Tsani Fadhilatul Aulia'], ['Defira', 'Defira Nafi Camila'], ['Alifya', 'Alifya Rostaviani'], ['Sita', 'Sita Dewi Oktapia']],
  Jumat: [['Munggaran', 'Munggaran Pratama'], ['Fahrizal', 'Muhammad Fahrizal Fahri'], ['Fellicha', 'Fellicha Nuraeni Firmansyah'], ['Ferdisha', 'Ferdisha Anna Altafunisa'], ['Almaretha', 'Almaretha Sarahilla Soerya'], ['Umu', 'Umu Bilqis Hafifah'], ['Annisa', 'Annisa Fitri Ramadhani'], ['Khalisha', 'Khalisha Alyapoetry Hadi']]
};
// [username, password awal, nama] - password bisa diganti langsung di sheet Guru
var GURU = [['buani', 'ani128', 'Bu Ani'], ['abdurachman', 'tik128', 'Pak Abdurachman']];

// Jabatan pengurus kelas (kunci = username siswa, huruf kecil, sama seperti kolom Username di sheet Siswa)
var JABATAN = {
  'ahmad': 'KM', 'fahrizal': 'Wakil KM',
  'khalisha': 'Sekretaris', 'marsela': 'Wakil Sekretaris',
  'adinda': 'Bendahara', 'annisa': 'Wakil Bendahara',
  'sita': 'Sie Kebersihan', 'zefanya': 'Sie Kebersihan',
  'fiqri': 'Sie Keamanan', 'tsani': 'Sie Keamanan',
  'andrea': 'Sie Olahraga & Kesehatan', 'tias': 'Sie Olahraga & Kesehatan',
  'ferdisha': 'Sie Pendidikan', 'alya': 'Sie Pendidikan',
  'ali': 'Sie Kerohanian', 'yanesa': 'Sie Kerohanian',
  'afwa': 'Sie Seni dan Keindahan', 'kanza': 'Sie Seni dan Keindahan'
};
// Yang boleh membuat polling (selain guru) dan mengisi agenda (selain guru)
var PENGURUS = ['KM', 'Wakil KM', 'Sekretaris', 'Bendahara'];
var PENGISI_AGENDA = ['Sekretaris', 'Wakil Sekretaris'];
function jab_(u) { return JABATAN[String(u || '').toLowerCase()] || ''; }
// Guru selalu boleh; siswa hanya jika jabatannya ada di daftar 'boleh'
function authPengurus_(t, boleh) {
  var u = auth_(t);
  if (u.role === 'teacher') return u;
  if (u.role === 'student' && boleh.indexOf(jab_(u.username)) >= 0) return u;
  throw new Error('Akses ditolak. Fitur ini khusus ' + boleh.join(', ') + '.');
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('TWELVOLNA.EIGHTHEREALIS')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}


/* ---------- API untuk web yang dihosting di luar Apps Script (fetch POST) ---------- */
// Hanya fungsi di daftar ini yang boleh dipanggil dari luar. Fungsi admin/setup sengaja tidak dimasukkan.
var API_OK_ = {};
['loginUser','restoreSession','logoutUser','getStudentDashboard','getStudentHistory','getStudentStatistics',
 'getPicketSchedule','getTodayPicket','submitAttendance','submitPicket','savePicketPhoto','saveProfilePhoto',
 'getTeacherDashboard','getClassStatistics','postAnnouncement','deleteAnnouncement','getStudentDetail',
 'getLeaderboard','getRecap','teacherSetAttendance','addCashPayment','updateCashPayment','getExplore',
 'postAgenda','deleteAgenda','addAgendaPhoto','createPoll','votePoll','closePoll','sendKudos','deleteKudos',
 'sendSaran','getSaran','deleteSaran','addCashExpense','cancelCashExpense','daftarPerangkat'
].forEach(function (n) { API_OK_[n] = 1; });

function doPost(e) {
  var out;
  try {
    var req = JSON.parse(e.postData.contents);
    if (!API_OK_[req.fn]) throw new Error('Fungsi tidak dikenal.');
    out = { result: this[req.fn].apply(null, req.args || []) };
  } catch (err) {
    out = { error: String(err && err.message || err) };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------- Helper ---------- */
function ss_() { return SpreadsheetApp.openById(SS_ID); }
function stamp_(f) { return Utilities.formatDate(new Date(), TZ, f); }
function nowInfo_() {
  return { ts: stamp_('yyyy-MM-dd HH:mm:ss'), tgl: stamp_('yyyy-MM-dd'), hari: HARI[Number(stamp_('u')) % 7] };
}
function sheet_(n) {
  var s = ss_(), sh = s.getSheetByName(n);
  if (!sh) sh = s.insertSheet(n);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, sh.getMaxRows(), H[n].length).setNumberFormat('@');
    sh.getRange(1, 1, 1, H[n].length).setValues([H[n]]).setFontWeight('bold');
    sh.setFrozenRows(1);
  } else if (sh.getLastColumn() < H[n].length) {
    sh.getRange(1, 1, 1, H[n].length).setValues([H[n]]).setFontWeight('bold');
  }
  return sh;
}
function rows_(n) {
  var v = sheet_(n).getDataRange().getDisplayValues(), h = v[0], o = [];
  for (var i = 1; i < v.length; i++) {
    var r = {};
    for (var j = 0; j < h.length; j++) r[h[j]] = String(v[i][j]).trim();
    if (r[h[0]]) o.push(r);
  }
  return o;
}
function folder_(n) {
  var it = DriveApp.getFoldersByName(n);
  return it.hasNext() ? it.next() : DriveApp.createFolder(n);
}
function aktif_(v) { return String(v).toUpperCase() === 'TRUE'; }
function wrap_(f) {
  try { return f(); } catch (e) { return { ok: false, msg: String(e && e.message ? e.message : e) }; }
}
function auth_(t, role) {
  var c = t ? CacheService.getScriptCache().get('tk_' + t) : null;
  var u = c ? JSON.parse(c) : verifyToken_(t);
  if (!u) throw new Error('Sesi berakhir. Silakan masuk lagi.');
  if (role && u.role !== role) throw new Error('Akses ditolak.');
  return u;
}
function profFoto_(u) {
  var r = rows_('Profil').filter(function (x) { return x.Username.toLowerCase() === u; })[0];
  return r ? r.FotoID : '';
}
function isScheduled_(hari, username) {
  return (JADWAL[hari] || []).some(function (x) { return x[0].toLowerCase() === username; });
}
function saveBlob_(durl, name, folderName) {
  var s = String(durl || ''), i = s.indexOf('base64,');
  if (i < 0) throw new Error('Format foto tidak valid.');
  var blob = Utilities.newBlob(Utilities.base64Decode(s.substring(i + 7)), 'image/jpeg', name);
  var f = folder_(folderName).createFile(blob);
  try { f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  return f;
}

/* ---------- Setup ---------- */
function setupDatabase() {
  Object.keys(H).forEach(function (n) { sheet_(n); });
  var have = {}, add = [], sw = sheet_('Siswa');
  rows_('Siswa').forEach(function (r) { have[r.Username.toLowerCase()] = 1; });
  var all = [];
  Object.keys(JADWAL).forEach(function (d) {
    JADWAL[d].forEach(function (x) { all.push([x[0].toLowerCase(), x[1]]); });
  });
  all.sort(function (a, b) { return a[1].localeCompare(b[1]); });
  all.forEach(function (s) {
    if (!have[s[0]]) add.push([s[0], s[0] + '128', s[1], KELAS, 'student', 'TRUE']);
  });
  if (add.length) sw.getRange(sw.getLastRow() + 1, 1, add.length, 6).setValues(add);

  var hg = {}, ag = [], sg = sheet_('Guru');
  rows_('Guru').forEach(function (r) { hg[r.Username.toLowerCase()] = 1; });
  GURU.forEach(function (g) { if (!hg[g[0]]) ag.push([g[0], g[1], g[2], 'teacher', 'TRUE']); });
  if (ag.length) sg.getRange(sg.getLastRow() + 1, 1, ag.length, 5).setValues(ag);

  var sj = sheet_('JadwalPiket');
  if (sj.getLastRow() <= 1) {
    var jr = [];
    Object.keys(JADWAL).forEach(function (d) {
      JADWAL[d].forEach(function (x) { jr.push([d, x[0].toLowerCase(), x[1]]); });
    });
    sj.getRange(2, 1, jr.length, 3).setValues(jr);
  }
  folder_(F_BUKTI);
  folder_(F_PROFIL);
  folder_(F_AGENDA);
  return 'Setup selesai: ' + all.length + ' siswa, ' + GURU.length + ' guru.';
}

/* ---------- Login & sesi ---------- */
function loginUser(username, password) {
  return wrap_(function () {
    var u = String(username || '').trim().toLowerCase(), p = String(password || '').trim();
    if (!u || !p) return { ok: false, msg: 'Username atau password salah.' };
    var f = null, role = '';
    rows_('Siswa').forEach(function (r) {
      if (!f && r.Username.toLowerCase() === u && r.Password === p) { f = r; role = 'student'; }
    });
    if (!f) rows_('Guru').forEach(function (r) {
      if (!f && r.Username.toLowerCase() === u && r.Password === p) { f = r; role = 'teacher'; }
    });
    if (!f) return { ok: false, msg: 'Username atau password salah.' };
    if (!aktif_(f.Aktif)) return { ok: false, msg: 'Akun ini tidak aktif.' };
    var user = { username: f.Username.toLowerCase(), nama: f.Nama, kelas: f.Kelas || KELAS, role: role, jabatan: role === 'student' ? jab_(f.Username) : '' };
    user.foto = profFoto_(user.username);
    var t = makeToken_(user.username, role);
    CacheService.getScriptCache().put('tk_' + t, JSON.stringify(user), 21600);
    return { ok: true, token: t, user: user, dash: role === 'student' ? buildStudent_(user) : buildTeacher_() };
  });
}
/* ---------- Sesi 30 hari (token bertanda tangan, tanpa simpan di sheet) ---------- */
var SESI_HARI = 30;
function secret_() {
  var p = PropertiesService.getScriptProperties(), s = p.getProperty('SESI_SECRET');
  if (!s) { s = Utilities.getUuid() + Utilities.getUuid(); p.setProperty('SESI_SECRET', s); }
  return s;
}
function sign_(v) { return Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(v, secret_())); }
function makeToken_(username, role) {
  var body = Utilities.base64EncodeWebSafe(username + '|' + role + '|' + (Date.now() + SESI_HARI * 86400000));
  return body + '.' + sign_(body);
}
function verifyToken_(t) {
  try {
    var p = String(t || '').split('.');
    if (p.length !== 2 || sign_(p[0]) !== p[1]) return null;
    var d = Utilities.newBlob(Utilities.base64DecodeWebSafe(p[0])).getDataAsString().split('|');
    if (d.length !== 3 || Number(d[2]) < Date.now()) return null;
    var un = d[0], role = d[1];
    var f = rows_(role === 'teacher' ? 'Guru' : 'Siswa').filter(function (r) { return r.Username.toLowerCase() === un && aktif_(r.Aktif); })[0];
    if (!f) return null;
    var user = { username: un, nama: f.Nama, kelas: f.Kelas || KELAS, role: role, jabatan: role === 'student' ? jab_(un) : '' };
    user.foto = profFoto_(un);
    CacheService.getScriptCache().put('tk_' + t, JSON.stringify(user), 21600);
    return user;
  } catch (e) { return null; }
}
function restoreSession(token) {
  return wrap_(function () {
    var u = auth_(token);
    return { ok: true, token: token, user: u, dash: u.role === 'student' ? buildStudent_(u) : buildTeacher_() };
  });
}
function logoutUser(token) {
  return wrap_(function () {
    if (token) CacheService.getScriptCache().remove('tk_' + token);
    return { ok: true };
  });
}

/* ---------- Siswa ---------- */
function stats_(a, pk) {
  var s = { hadir: 0, izin: 0, sakit: 0, alpa: 0, piket: pk.length };
  a.forEach(function (r) { var k = r.Status.toLowerCase(); if (s[k] !== undefined) s[k]++; });
  return s;
}
function hist_(a, pk) {
  var h = [];
  a.forEach(function (r) { h.push({ ts: r.Timestamp, tgl: r.Tanggal, tipe: 'Kehadiran', ket: r.Status + (r.Alasan ? ' - ' + r.Alasan : '') }); });
  pk.forEach(function (r) { h.push({ ts: r.Timestamp, tgl: r.Tanggal, tipe: 'Piket', ket: r.Status }); });
  h.sort(function (x, y) { return x.ts < y.ts ? 1 : -1; });
  return h.slice(0, 100);
}
function buildStudent_(user) {
  var n = nowInfo_();
  var a = rows_('Absensi').filter(function (r) { return r.Username.toLowerCase() === user.username; });
  var pk = rows_('Piket').filter(function (r) { return r.Username.toLowerCase() === user.username; });
  var ab = a.filter(function (r) { return r.Tanggal === n.tgl; })[0];
  var pt = pk.filter(function (r) { return r.Tanggal === n.tgl; })[0];
  return {
    ok: true, tgl: n.tgl, hari: n.hari,
    absen: ab ? { status: ab.Status, alasan: ab.Alasan } : null,
    piket: {
      scheduled: isScheduled_(n.hari, user.username), done: !!pt,
      keterangan: pt ? pt.Keterangan : '', fotoUrl: pt ? pt.FotoURL : '', fotoId: pt ? pt.FotoID : ''
    },
    stats: stats_(a, pk), history: hist_(a, pk), jadwal: JADWAL, info: annc_()
  };
}
function getStudentDashboard(username, token) {
  return wrap_(function () { return buildStudent_(auth_(token, 'student')); });
}
function getStudentHistory(username, token) {
  return wrap_(function () { var d = buildStudent_(auth_(token, 'student')); return { ok: true, history: d.history }; });
}
function getStudentStatistics(username, token) {
  return wrap_(function () { var d = buildStudent_(auth_(token, 'student')); return { ok: true, stats: d.stats }; });
}
function getPicketSchedule(token) {
  return wrap_(function () { auth_(token); return { ok: true, jadwal: JADWAL, hari: nowInfo_().hari }; });
}
function getTodayPicket(username, token) {
  return wrap_(function () { var d = buildStudent_(auth_(token, 'student')); return { ok: true, hari: d.hari, piket: d.piket }; });
}

function submitAttendance(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token, 'student'), st = String(d.status || ''), al = String(d.alasan || '').trim();
    if (['Hadir', 'Izin', 'Sakit', 'Alpa'].indexOf(st) < 0) throw new Error('Pilih status kehadiran.');
    if (st !== 'Hadir' && !al) throw new Error('Silakan isi alasan terlebih dahulu.');
    var lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      var n = nowInfo_();
      var dup = rows_('Absensi').some(function (r) { return r.Username.toLowerCase() === u.username && r.Tanggal === n.tgl; });
      if (dup) throw new Error('Kamu sudah mengisi absensi hari ini.');
      sheet_('Absensi').appendRow([n.ts, n.tgl, n.hari, u.username, u.nama, u.kelas, st, al]);
    } finally { lock.releaseLock(); }
    var r = buildStudent_(u);
    r.msg = 'Absensi berhasil disimpan.';
    return r;
  });
}

function submitPicket(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token, 'student'), n = nowInfo_();
    var me = rows_('Siswa').filter(function (r) { return r.Username.toLowerCase() === u.username; })[0];
    if (!me || !aktif_(me.Aktif)) throw new Error('Akun ini tidak aktif.');
    if (!isScheduled_(n.hari, u.username)) throw new Error('Hari ini bukan jadwal piket kamu.');
    var ket = String(d.keterangan || '').trim().substring(0, 300);
    if (!ket) throw new Error('Silakan isi keterangan piket.');
    if (!d.foto) throw new Error('Silakan ambil foto bukti piket.');
    var lock = LockService.getScriptLock();
    lock.waitLock(30000);
    try {
      var dup = rows_('Piket').some(function (r) { return r.Username.toLowerCase() === u.username && r.Tanggal === n.tgl; });
      if (dup) throw new Error('Kamu sudah menyelesaikan piket hari ini.');
      var name = 'PIKET_' + n.tgl.replace(/-/g, '') + '_' + u.username + '_' + n.ts.replace(/\D/g, '') + '.jpg';
      var f = saveBlob_(d.foto, name, F_BUKTI);
      sheet_('Piket').appendRow([n.ts, n.tgl, n.hari, u.username, u.nama, u.kelas, 'Sudah Piket', ket, f.getUrl(), f.getId()]);
    } finally { lock.releaseLock(); }
    var r = buildStudent_(u);
    r.msg = 'Piket berhasil disimpan.';
    return r;
  });
}

function savePicketPhoto(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token, 'student'), n = nowInfo_();
    var f = saveBlob_(d.foto, 'PIKET_' + n.tgl.replace(/-/g, '') + '_' + u.username + '_' + n.ts.replace(/\D/g, '') + '.jpg', F_BUKTI);
    return { ok: true, url: f.getUrl(), id: f.getId() };
  });
}
function saveProfilePhoto(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token), n = nowInfo_();
    var f = saveBlob_(d.foto, 'PROFIL_' + u.username + '_' + n.ts.replace(/\D/g, '') + '.jpg', F_PROFIL);
    var sh = sheet_('Profil'), v = sh.getDataRange().getValues(), row = 0;
    for (var i = 1; i < v.length; i++) if (String(v[i][0]) === u.username) row = i + 1;
    var data = [u.username, u.nama, f.getUrl(), f.getId(), n.ts];
    if (row) sh.getRange(row, 1, 1, 5).setValues([data]); else sh.appendRow(data);
    return { ok: true, url: f.getUrl(), id: f.getId() };
  });
}

/* ---------- Guru ---------- */
function buildTeacher_() {
  var n = nowInfo_(), ab = {}, pk = {}, list = [];
  rows_('Absensi').forEach(function (r) { if (r.Tanggal === n.tgl) ab[r.Username.toLowerCase()] = r; });
  rows_('Piket').forEach(function (r) { if (r.Tanggal === n.tgl) pk[r.Username.toLowerCase()] = r; });
  var c = { total: 0, sudahAbsen: 0, belumAbsen: 0, Hadir: 0, Izin: 0, Sakit: 0, Alpa: 0, sudahPiket: 0, belumPiket: 0, tidakJadwal: 0 };
  rows_('Siswa').forEach(function (s) {
    if (!aktif_(s.Aktif)) return;
    var k = s.Username.toLowerCase(), a = ab[k], p = pk[k], sc = isScheduled_(n.hari, k);
    var sp = !sc ? 'Tidak Ada Jadwal' : (p ? 'Sudah Piket' : 'Belum Piket');
    c.total++;
    if (a) { c.sudahAbsen++; if (c[a.Status] !== undefined) c[a.Status]++; } else c.belumAbsen++;
    if (sp === 'Sudah Piket') c.sudahPiket++; else if (sp === 'Belum Piket') c.belumPiket++; else c.tidakJadwal++;
    list.push({
      no: list.length + 1, username: k, nama: s.Nama, kelas: s.Kelas || KELAS,
      absensi: a ? a.Status : 'Belum Absen', alasan: a ? a.Alasan : '',
      jadwal: sc, piket: sp, ket: p ? p.Keterangan : '', fotoUrl: p ? p.FotoURL : '', fotoId: p ? p.FotoID : ''
    });
  });
  return { ok: true, tgl: n.tgl, hari: n.hari, c: c, rows: list, info: annc_() };
}
function getTeacherDashboard(token) {
  return wrap_(function () { auth_(token, 'teacher'); return buildTeacher_(); });
}
function getClassStatistics(token) {
  return wrap_(function () { auth_(token, 'teacher'); var d = buildTeacher_(); return { ok: true, c: d.c }; });
}

/* ---------- Pengumuman & detail siswa ---------- */
function annc_() {
  return rows_('Pengumuman')
    .sort(function (a, b) { return a.Timestamp < b.Timestamp ? 1 : -1; })
    .slice(0, 5)
    .map(function (r) { return { tgl: r.Tanggal, isi: r.Isi, oleh: r.Oleh, ts: r.Timestamp }; });
}
function postAnnouncement(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token, 'teacher'), isi = String(d.isi || '').trim().substring(0, 300);
    if (!isi) throw new Error('Tulis pengumuman terlebih dahulu.');
    var n = nowInfo_();
    sheet_('Pengumuman').appendRow([n.ts, n.tgl, isi, u.nama]);
    var r = buildTeacher_();
    r.msg = 'Pengumuman terkirim.';
    return r;
  });
}
function deleteAnnouncement(d) {
  return wrap_(function () {
    d = d || {};
    auth_(d.token, 'teacher');
    withLock_(function () { delRow_('Pengumuman', 0, String(d.ts || '')); });
    var r = buildTeacher_();
    r.msg = 'Pengumuman dihapus.';
    return r;
  });
}
function getStudentDetail(username, token) {
  return wrap_(function () {
    auth_(token, 'teacher');
    var k = String(username || '').toLowerCase();
    var me = rows_('Siswa').filter(function (r) { return r.Username.toLowerCase() === k; })[0];
    if (!me) throw new Error('Siswa tidak ditemukan.');
    var d = buildStudent_({ username: k, nama: me.Nama });
    return { ok: true, stats: d.stats, history: d.history.slice(0, 10) };
  });
}

/* ---------- Peringkat, rekap bulanan, guru isi absensi ---------- */
function getLeaderboard(token) {
  return wrap_(function () {
    auth_(token);
    var names = {}, h = {}, p = {}, tot = 0, hd = 0;
    rows_('Siswa').forEach(function (r) { if (aktif_(r.Aktif)) names[r.Username.toLowerCase()] = r.Nama; });
    rows_('Absensi').forEach(function (r) {
      var k = r.Username.toLowerCase(); tot++;
      if (r.Status === 'Hadir') { hd++; h[k] = (h[k] || 0) + 1; }
    });
    rows_('Piket').forEach(function (r) { var k = r.Username.toLowerCase(); p[k] = (p[k] || 0) + 1; });
    function top(o) {
      return Object.keys(o).filter(function (k) { return names[k]; })
        .map(function (k) { return { nama: names[k], n: o[k] }; })
        .sort(function (a, b) { return b.n - a.n; }).slice(0, 5);
    }
    return { ok: true, rajin: top(h), piket: top(p), pct: tot ? Math.round(hd * 100 / tot) : 0 };
  });
}
function getRecap(token, bulan) {
  return wrap_(function () {
    auth_(token, 'teacher');
    var b = /^\d{4}-\d{2}$/.test(String(bulan || '')) ? String(bulan) : nowInfo_().tgl.substring(0, 7);
    var m = {}, list = [];
    rows_('Siswa').forEach(function (s) {
      if (!aktif_(s.Aktif)) return;
      m[s.Username.toLowerCase()] = { nama: s.Nama, hadir: 0, izin: 0, sakit: 0, alpa: 0, piket: 0 };
    });
    rows_('Absensi').forEach(function (r) {
      var x = m[r.Username.toLowerCase()], k = r.Status.toLowerCase();
      if (x && r.Tanggal.substring(0, 7) === b && x[k] !== undefined) x[k]++;
    });
    rows_('Piket').forEach(function (r) {
      var x = m[r.Username.toLowerCase()];
      if (x && r.Tanggal.substring(0, 7) === b) x.piket++;
    });
    Object.keys(m).forEach(function (k) {
      var x = m[k], t = x.hadir + x.izin + x.sakit + x.alpa;
      x.pct = t ? Math.round(x.hadir * 100 / t) : 0;
      list.push(x);
    });
    list.sort(function (a, b) { return a.nama.localeCompare(b.nama); });
    return { ok: true, bulan: b, rows: list };
  });
}
function teacherSetAttendance(d) {
  return wrap_(function () {
    d = d || {};
    auth_(d.token, 'teacher');
    var st = String(d.status || ''), al = String(d.alasan || '').trim().substring(0, 200);
    if (['Hadir', 'Izin', 'Sakit', 'Alpa'].indexOf(st) < 0) throw new Error('Pilih status kehadiran.');
    if (st !== 'Hadir' && !al) throw new Error('Silakan isi alasan terlebih dahulu.');
    var k = String(d.username || '').toLowerCase();
    var me = rows_('Siswa').filter(function (r) { return r.Username.toLowerCase() === k; })[0];
    if (!me) throw new Error('Siswa tidak ditemukan.');
    var lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      var n = nowInfo_(), sh = sheet_('Absensi'), v = sh.getDataRange().getDisplayValues(), row = 0;
      for (var i = 1; i < v.length; i++) if (v[i][3].toLowerCase() === k && v[i][1] === n.tgl) row = i + 1;
      var note = (al ? al + ' ' : '') + '[diisi guru]';
      var data = [n.ts, n.tgl, n.hari, k, me.Nama, me.Kelas || KELAS, st, note];
      if (row) sh.getRange(row, 1, 1, 8).setValues([data]); else sh.appendRow(data);
    } finally { lock.releaseLock(); }
    var r = buildTeacher_();
    r.msg = 'Absensi ' + me.Nama + ' disimpan.';
    return r;
  });
}

/* ---------- Jelajah: anggota, agenda, polling, apresiasi ---------- */
function members_() {
  var fm = {}, hari = {};
  rows_('Profil').forEach(function (r) { fm[r.Username.toLowerCase()] = r.FotoID; });
  Object.keys(JADWAL).forEach(function (d) { JADWAL[d].forEach(function (x) { hari[x[0].toLowerCase()] = d; }); });
  return rows_('Siswa').filter(function (r) { return aktif_(r.Aktif); })
    .map(function (r) { var k = r.Username.toLowerCase(); return { u: k, nama: r.Nama, foto: fm[k] || '', hari: hari[k] || '', jab: JABATAN[k] || '' }; })
    .sort(function (a, b) { return a.nama.localeCompare(b.nama); });
}
function agenda_() {
  var lim = Utilities.formatDate(new Date(Date.now() - 3 * 86400000), TZ, 'yyyy-MM-dd');
  return rows_('Agenda').filter(function (r) { return r.Tanggal >= lim; })
    .sort(function (a, b) { return a.Tanggal < b.Tanggal ? -1 : 1; }).slice(0, 40)
    .map(function (r) { return { id: r.Timestamp, tgl: r.Tanggal, jenis: r.Jenis, judul: r.Judul, cat: r.Catatan, oleh: r.Oleh, foto: r.FotoID || '' }; });
}
function polls_(k) {
  var sv = rows_('Suara'), out = [];
  rows_('Polling').sort(function (a, b) { return a.Timestamp < b.Timestamp ? 1 : -1; }).slice(0, 5).forEach(function (p) {
    var o = p.Opsi.split('|'), c = o.map(function () { return 0; }), mine = -1;
    sv.forEach(function (v) {
      if (v.PollID === p.ID) {
        var i = Number(v.Pilihan);
        if (c[i] !== undefined) c[i]++;
        if (v.Username.toLowerCase() === k) mine = i;
      }
    });
    out.push({ id: p.ID, q: p.Pertanyaan, opts: o, counts: c, mine: mine, open: p.Status === 'Buka', oleh: p.Oleh,
      total: c.reduce(function (a, b) { return a + b; }, 0) });
  });
  return out;
}
function kudos_() {
  return rows_('Apresiasi').sort(function (a, b) { return a.Timestamp < b.Timestamp ? 1 : -1; }).slice(0, 20)
    .map(function (r) { return { ts: r.Timestamp, dari: r.Dari, untuk: r.Untuk, pesan: r.Pesan }; });
}
function exploreData_(u) {
  return { ok: true, members: members_(), agenda: agenda_(), polls: polls_(u.username), kudos: kudos_(), kas: kas_(u), jab: u.role === 'student' ? jab_(u.username) : '' };
}
var BENDAHARA = ['Bendahara'];
var IURAN = 10000, KAS_MULAI = '2026-07';
function authBendahara_(t) {
  var u = auth_(t);
  if (u.role === 'student' && BENDAHARA.indexOf(jab_(u.username)) >= 0) return u;
  throw new Error('Tidak memiliki akses.');
}
function kasKey_(y, m) { return y + '-' + (m < 10 ? '0' : '') + m; }
function kasNext_(k) { var y = +k.slice(0, 4), m = +k.slice(5) + 1; if (m > 12) { m = 1; y++; } return kasKey_(y, m); }
function kasMonths_(rows) {
  var last = nowInfo_().tgl.substring(0, 7), out = [], k = KAS_MULAI;
  rows.forEach(function (r) { var x = kasKey_(Number(r.Tahun), Number(r.Bulan)); if (Number(r.NominalBayar) > 0 && x > last) last = x; });
  while (k <= last) { out.push(k); k = kasNext_(k); }
  return out;
}
// Data kas untuk semua pengguna login: tabel kelas terlihat semua; catatan hanya milik sendiri (atau bendahara/guru)
function kas_(u) {
  // Jika sheet Kas masih kosong, isi otomatis dari laporan awal (hanya sekali)
  try { if (sheet_('Kas').getLastRow() <= 1) withLock_(function () { if (sheet_('Kas').getLastRow() <= 1) isiKasAwal(); }); } catch (e) { Logger.log('Auto-isi kas gagal: ' + e); }
  var rows = rows_('Kas'), by = {}, cat = {};
  rows.forEach(function (r) {
    var k = kasKey_(Number(r.Tahun), Number(r.Bulan)), un = String(r.Username).toLowerCase();
    (by[un] = by[un] || {})[k] = Number(r.NominalBayar) || 0;
    if (r.Catatan) (cat[un] = cat[un] || {})[k] = r.Catatan;
  });
  var adm = u.role === 'teacher' || BENDAHARA.indexOf(jab_(u.username)) >= 0, me = String(u.username || '').toLowerCase();
  var st = rows_('Siswa').filter(function (r) { return aktif_(r.Aktif); })
    .sort(function (a, b) { return a.Nama.localeCompare(b.Nama); })
    .map(function (r) { var un = r.Username.toLowerCase(); return { u: un, n: r.Nama, m: by[un] || {}, c: (adm || un === me) ? (cat[un] || {}) : {} }; });
  var hist = rows.filter(function (r) { return adm || String(r.Username).toLowerCase() === me; })
    .sort(function (a, b) { return a.UpdatedAt < b.UpdatedAt ? 1 : -1; }).slice(0, 60)
    .map(function (r) { return { tgl: r.Tanggal, nama: r.Nama, bln: kasKey_(Number(r.Tahun), Number(r.Bulan)), jml: Number(r.NominalBayar) || 0, st: r.Status, cat: r.Catatan, oleh: r.UpdatedBy }; });
  var ex = kasKeluar_(), masuk = 0;
  rows.forEach(function (r) { masuk += Number(r.NominalBayar) || 0; });
  return { iuran: IURAN, masuk: masuk, months: kasMonths_(rows), cur: nowInfo_().tgl.substring(0, 7), st: st, hist: hist, out: ex.list, keluar: ex.total };
}
function kasNama_(un) {
  var s = rows_('Siswa').filter(function (r) { return r.Username.toLowerCase() === un && aktif_(r.Aktif); })[0];
  if (!s) throw new Error('Siswa tidak ditemukan.');
  return s.Nama;
}
function kasGet_(un, key) {
  var v = sheet_('Kas').getDataRange().getDisplayValues(), id = un + '|' + key;
  for (var i = 1; i < v.length; i++) if (v[i][0] === id) return { row: i + 1, bayar: Number(v[i][7]) || 0, cat: v[i][10] };
  return { row: 0, bayar: 0, cat: '' };
}
function kasSet_(un, nama, key, bayar, cat, by) {
  var cur = kasGet_(un, key), n = nowInfo_(), sh = sheet_('Kas');
  var st = bayar >= IURAN ? 'Lunas' : bayar > 0 ? 'Kurang' : 'Belum Bayar';
  var rec = [un + '|' + key, n.tgl, Number(key.slice(5)), Number(key.slice(0, 4)), un, nama, IURAN, bayar, Math.max(0, IURAN - bayar), st, cat === null ? cur.cat : cat, n.ts, by];
  if (cur.row) sh.getRange(cur.row, 1, 1, 13).setValues([rec]); else sh.appendRow(rec);
}
// Tambah pembayaran.
// - d.bulan berupa daftar bulan (mode "pilih"): tiap bulan terpilih ditambah d.jml (maks Rp10.000/bulan), bulan boleh loncat-loncat
// - d.bulan berupa satu bulan (mode "beruntun"): total d.jml mengisi bulan itu sampai Rp10.000, kelebihan lanjut ke bulan berikutnya
function addCashPayment(d) {
  return wrap_(function () {
    d = d || {};
    var u = authBendahara_(d.token), un = String(d.username || '').toLowerCase(), amt = Math.round(Number(d.jml));
    var keys = (d.bulan instanceof Array ? d.bulan : [d.bulan]).map(String).filter(function (k, i, a) { return a.indexOf(k) === i; }).sort();
    if (!keys.length || keys.length > 36) throw new Error('Pilih 1 sampai 36 bulan.');
    keys.forEach(function (k) { if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(k)) throw new Error('Bulan tidak valid.'); });
    var nama = kasNama_(un), cat = String(d.cat || '').trim().substring(0, 120), done = 0, total = 0;
    if (d.bulan instanceof Array) {
      if (!(amt > 0 && amt <= IURAN)) throw new Error('Nominal per bulan harus antara Rp1 dan Rp' + IURAN.toLocaleString('id-ID') + '.');
      withLock_(function () {
        keys.forEach(function (key) {
          var cur = kasGet_(un, key).bayar, put = Math.min(Math.max(0, IURAN - cur), amt);
          if (put > 0) { kasSet_(un, nama, key, cur + put, cat || null, u.nama); done++; total += put; }
        });
      });
      if (!done) throw new Error('Bulan yang dipilih sudah lunas semua.');
    } else {
      if (!(amt > 0 && amt <= 360000)) throw new Error('Nominal tidak valid (maksimal Rp360.000 sekali catat).');
      withLock_(function () {
        var left = amt, guard = 0, first = true, key = keys[0];
        while (left > 0 && guard++ < 36) {
          var cur = kasGet_(un, key).bayar, put = Math.min(Math.max(0, IURAN - cur), left);
          if (put > 0) { kasSet_(un, nama, key, cur + put, first ? (cat || null) : null, u.nama); first = false; left -= put; done++; total += put; }
          key = kasNext_(key);
        }
      });
    }
    var r = exploreData_(u); r.msg = 'Pembayaran dicatat: Rp' + total.toLocaleString('id-ID') + ' untuk ' + done + ' bulan.'; return r;
  });
}
// Ubah nominal satu bulan menjadi angka tertentu (koreksi)
function updateCashPayment(d) {
  return wrap_(function () {
    d = d || {};
    var u = authBendahara_(d.token), un = String(d.username || '').toLowerCase(), key = String(d.bulan || ''), amt = Math.round(Number(d.jml));
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(key)) throw new Error('Bulan tidak valid.');
    if (!(amt >= 0 && amt <= 1000000)) throw new Error('Nominal tidak valid.');
    var nama = kasNama_(un);
    withLock_(function () { kasSet_(un, nama, key, amt, d.cat === undefined ? null : String(d.cat).trim().substring(0, 120), u.nama); });
    var r = exploreData_(u); r.msg = 'Data kas diperbarui.'; return r;
  });
}
// [nama lengkap, lunas sampai (yyyy-mm), kekurangan di bulan terakhir, catatan opsional]
var KAS_AWAL = [
  ['Adinda Putri Ilmi Syakina', '2026-10', 0], ['Adzra Dwi Ginanjar', '2026-10', 0], ['Ahmad Feriansyah', '2027-01', 0],
  ['Andrea Julian Alif Fadillah', '2026-10', 5000], ['Annisa Fitri Ramadhani', '2026-10', 0], ['Aura Nathania Putri Jatnika', '2026-10', 0],
  ['Defira Nafi Camila', '2026-10', 0], ['Hilda Aulia', '2026-10', 0], ['Khalisha Alyapoetry Hadi', '2026-11', 0],
  ['M. Abdul Muta Ali', '2026-10', 0], ['Muhamad Daffa Alwy Henryansyah', '2026-11', 0], ['Muhammad Fahrizal Fahri', '2026-11', 0],
  ['Umu Bilqis Hafifah', '2026-10', 0], ['Salma Aulia Nur Insani', '2026-11', 0], ['Zefanya Akira Yumna', '2026-11', 0],
  ['Ferdisha Anna Altafunisa', '2026-09', 0], ['Freedella Jacinda Hilman', '2026-09', 0], ['Kanza Almyra Irawanda', '2026-09', 0],
  ['Marsela Eka Cahyani', '2026-09', 0], ['Ratu Ayu Pratiwi', '2026-09', 0],
  ['Tsani Fadhilatul Aulia', '2026-09', 0, 'Data awal: laporan menyebut Agustus dan September, mohon dicek bendahara'],
  ['Yanesa Agustina', '2026-09', 0], ['Yolanda Putri Utami', '2026-09', 0],
  ['Afwa Rukhaniah Amijaya', '2026-08', 0], ['Almaretha Sarahilla Soerya', '2026-08', 0], ['Khanaya Aghita Hermanto', '2026-08', 1000],
  ['Fiqri Imamul Hidayah', '2026-08', 5000], ['Muhammad Khailan Alividi', '2026-08', 7000], ['Nadia Isaura Fajriah', '2026-08', 7000],
  ['Alifya Rostaviani', '2026-07', 5000], ['Alya Alifia Husada', '2026-07', 0], ['Davin Alvino', '2026-07', 0],
  ['Fellicha Nuraeni Firmansyah', '2026-07', 5000], ['Ikhsan Kamil Muharam Nugraha', '2026-07', 5000], ['Tias Kamil', '2026-07', 0],
  ['M. Rafael Al Fatah', '2026-07', 0]
]; // Munggaran Pratama dan Sita Dewi Oktapia masih 0, jadi tidak punya baris
function kasToken_(x) { return String(x).toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter(String); }
// Cari siswa berdasarkan nama lengkap; jika tidak persis sama, pakai kecocokan kata terbanyak (minimal 2 kata, harus unik)
function kasCari_(nama, sis) {
  var key = String(nama).toLowerCase().replace(/\s+/g, ' ').trim();
  if (sis[key]) return sis[key];
  var t = kasToken_(nama), best = null, sc = 0, tie = false;
  Object.keys(sis).forEach(function (k) {
    var tk = kasToken_(sis[k].Nama), s = t.filter(function (w) { return tk.indexOf(w) >= 0; }).length;
    if (s > sc) { sc = s; best = sis[k]; tie = false; } else if (s === sc && s > 0) tie = true;
  });
  return sc >= 2 && !tie ? best : null;
}
// Jalankan sekali dari editor: mengisi data kas awal (aman dijalankan ulang, tidak membuat duplikat)
function isiKasAwal() {
  var sis = {}, sh = sheet_('Kas'), v = sh.getDataRange().getDisplayValues(), ada = {}, out = [], n = nowInfo_(), miss = [];
  rows_('Siswa').forEach(function (r) { sis[String(r.Nama).toLowerCase().replace(/\s+/g, ' ').trim()] = r; });
  for (var i = 1; i < v.length; i++) ada[v[i][0]] = 1;
  KAS_AWAL.forEach(function (a) {
    var s = kasCari_(a[0], sis);
    if (!s) { miss.push(a[0]); return; }
    var un = s.Username.toLowerCase();
    for (var k = KAS_MULAI; k <= a[1]; k = kasNext_(k)) {
      var id = un + '|' + k;
      if (ada[id]) continue;
      var last = k === a[1], kr = last ? a[2] : 0, bayar = IURAN - kr, cat = last && a[3] ? a[3] : (kr ? 'Data awal: kurang ' + kr : '');
      out.push([id, n.tgl, Number(k.slice(5)), Number(k.slice(0, 4)), un, s.Nama, IURAN, bayar, kr, kr ? 'Kurang' : 'Lunas', cat, n.ts, 'Data awal']);
    }
  });
  if (out.length) sh.getRange(sh.getLastRow() + 1, 1, out.length, 13).setValues(out);
  var msg = 'Ditambahkan ' + out.length + ' baris.' + (miss.length ? ' Nama tidak ditemukan di sheet Siswa: ' + miss.join(', ') : '');
  Logger.log(msg);
  return msg;
}
function delRow_(sheetName, col, val, col2, val2) {
  var sh = sheet_(sheetName), v = sh.getDataRange().getDisplayValues();
  for (var i = v.length - 1; i >= 1; i--) {
    if (v[i][col] === val && (col2 === undefined || v[i][col2] === val2)) { sh.deleteRow(i + 1); return true; }
  }
  return false;
}
function withLock_(f) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return f(); } finally { lock.releaseLock(); }
}
function getExplore(token) {
  return wrap_(function () { return exploreData_(auth_(token)); });
}
function postAgenda(d) {
  return wrap_(function () {
    d = d || {};
    var u = authPengurus_(d.token, PENGISI_AGENDA), n = nowInfo_();
    var tgl = String(d.tgl || ''), jenis = String(d.jenis || ''), judul = String(d.judul || '').trim().substring(0, 80);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(tgl)) throw new Error('Tanggal tidak valid.');
    if (['Tugas', 'Ujian', 'Acara', 'Libur', 'Lainnya'].indexOf(jenis) < 0) jenis = 'Lainnya';
    if (!judul) throw new Error('Judul agenda wajib diisi.');
    var fids = [], ph = (d.fotos && d.fotos.length) ? d.fotos : (d.foto ? [d.foto] : []);
    ph.slice(0, 3).forEach(function (p, i) {
      if (String(p).length > 2500000) throw new Error('Ukuran foto terlalu besar.');
      fids.push(saveBlob_(p, 'AGENDA_' + tgl.replace(/-/g, '') + '_' + n.ts.replace(/\D/g, '') + '_' + (i + 1) + '.jpg', F_AGENDA).getId());
    });
    var fid = fids.join(',');
    sheet_('Agenda').appendRow([n.ts, tgl, jenis, judul, String(d.cat || '').trim().substring(0, 200), u.nama, fid]);
    var r = exploreData_(u); r.msg = 'Agenda ditambahkan.'; return r;
  });
}
function deleteAgenda(d) {
  return wrap_(function () {
    d = d || {};
    var u = authPengurus_(d.token, PENGISI_AGENDA);
    var old = rows_('Agenda').filter(function (r) { return r.Timestamp === String(d.id || ''); })[0];
    delRow_('Agenda', 0, String(d.id || ''));
    if (old && old.FotoID) old.FotoID.split(',').forEach(function (id) { try { DriveApp.getFileById(id).setTrashed(true); } catch (e) {} });
    var r = exploreData_(u); r.msg = 'Agenda dihapus.'; return r;
  });
}
function addAgendaPhoto(d) {
  return wrap_(function () {
    d = d || {};
    var u = authPengurus_(d.token, PENGISI_AGENDA), n = nowInfo_();
    if (!d.foto) throw new Error('Pilih foto dulu.');
    if (String(d.foto).length > 2500000) throw new Error('Ukuran foto terlalu besar.');
    withLock_(function () {
      var sh = sheet_('Agenda'), v = sh.getDataRange().getDisplayValues(), row = 0;
      for (var i = 1; i < v.length; i++) if (v[i][0] === String(d.id || '')) row = i + 1;
      if (!row) throw new Error('Agenda tidak ditemukan.');
      var cur = String(v[row - 1][6] || '').split(',').filter(String);
      if (cur.length >= 3) throw new Error('Maksimal 3 foto per agenda.');
      var f = saveBlob_(d.foto, 'AGENDA_' + n.ts.replace(/\D/g, '') + '_' + (cur.length + 1) + '.jpg', F_AGENDA);
      cur.push(f.getId());
      sh.getRange(row, 7).setNumberFormat('@').setValue(cur.join(','));
    });
    var r = exploreData_(u); r.msg = 'Foto ditambahkan.'; return r;
  });
}
function createPoll(d) {
  return wrap_(function () {
    d = d || {};
    var u = authPengurus_(d.token, PENGURUS), n = nowInfo_();
    var q = String(d.q || '').trim().substring(0, 120);
    var o = (d.opts || []).map(function (x) { return String(x).trim().substring(0, 50).replace(/\|/g, '/'); })
      .filter(function (x) { return x; }).slice(0, 5);
    if (!q) throw new Error('Tulis pertanyaan polling.');
    if (o.length < 2) throw new Error('Minimal 2 pilihan jawaban.');
    sheet_('Polling').appendRow(['P' + Date.now(), n.ts, q, o.join('|'), 'Buka', u.nama]);
    var r = exploreData_(u); r.msg = 'Polling dibuat.'; return r;
  });
}
function votePoll(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token, 'student'), id = String(d.pollId || ''), i = Number(d.idx);
    withLock_(function () {
      var p = rows_('Polling').filter(function (r) { return r.ID === id; })[0];
      if (!p) throw new Error('Polling tidak ditemukan.');
      if (p.Status !== 'Buka') throw new Error('Polling sudah ditutup.');
      if (!(i >= 0 && i < p.Opsi.split('|').length)) throw new Error('Pilihan tidak valid.');
      var dup = rows_('Suara').some(function (v) { return v.PollID === id && v.Username.toLowerCase() === u.username; });
      if (dup) throw new Error('Kamu sudah memberikan suara.');
      sheet_('Suara').appendRow([id, u.username, String(i), nowInfo_().ts]);
    });
    var r = exploreData_(u); r.msg = 'Suaramu tersimpan.'; return r;
  });
}
function closePoll(d) {
  return wrap_(function () {
    d = d || {};
    var u = authPengurus_(d.token, PENGURUS), sh = sheet_('Polling'), v = sh.getDataRange().getDisplayValues();
    for (var i = 1; i < v.length; i++) if (v[i][0] === String(d.pollId || '')) sh.getRange(i + 1, 5).setValue('Tutup');
    var r = exploreData_(u); r.msg = 'Polling ditutup.'; return r;
  });
}
function sendKudos(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token, 'student'), n = nowInfo_(), k = String(d.untuk || '').toLowerCase();
    var pesan = String(d.pesan || '').trim().substring(0, 140);
    if (!pesan) throw new Error('Tulis pesan apresiasi dulu.');
    if (k === u.username) throw new Error('Kirim ke temanmu ya, bukan ke diri sendiri 😄');
    var to = rows_('Siswa').filter(function (r) { return r.Username.toLowerCase() === k && aktif_(r.Aktif); })[0];
    if (!to) throw new Error('Teman tidak ditemukan.');
    withLock_(function () {
      var cnt = rows_('Apresiasi').filter(function (r) { return r.Dari === u.nama && r.Timestamp.substring(0, 10) === n.tgl; }).length;
      if (cnt >= 5) throw new Error('Maksimal 5 apresiasi per hari.');
      sheet_('Apresiasi').appendRow([n.ts, u.nama, to.Nama, pesan]);
    });
    var r = exploreData_(u); r.msg = 'Apresiasi terkirim 💌'; return r;
  });
}
function deleteKudos(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token, 'teacher');
    delRow_('Apresiasi', 0, String(d.ts || ''), 1, String(d.dari || ''));
    var r = exploreData_(u); r.msg = 'Apresiasi dihapus.'; return r;
  });
}

/* ---------- Kotak Saran (1x per bulan per siswa, anonim) ---------- */
function kodeSaran_(u) {
  var b = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'saran|' + String(u).toLowerCase());
  return b.map(function (x) { return ('0' + (x & 0xff).toString(16)).slice(-2); }).join('').substring(0, 20);
}
function sudahSaran_(u) {
  var bln = nowInfo_().tgl.substring(0, 7), k = kodeSaran_(u);
  return rows_('SaranLog').some(function (r) { return r.Bulan === bln && r.Kode === k; });
}
function sendSaran(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token, 'student'), n = nowInfo_();
    var isi = String(d.isi || '').trim().substring(0, 300);
    if (isi.length < 5) throw new Error('Tulis masukan minimal 5 huruf.');
    withLock_(function () {
      if (sudahSaran_(u.username)) throw new Error('Kamu sudah mengirim masukan bulan ini. Kotak saran dibuka lagi bulan depan.');
      sheet_('Saran').appendRow([n.ts, n.tgl, isi, 'Anonim']);
      sheet_('SaranLog').appendRow([n.tgl.substring(0, 7), kodeSaran_(u.username)]);
    });
    return { ok: true, sent: true, msg: 'Masukanmu terkirim. Terima kasih! 📮' };
  });
}
function saran_() {
  return rows_('Saran').sort(function (a, b) { return a.Timestamp < b.Timestamp ? 1 : -1; }).slice(0, 40)
    .map(function (r) { return { ts: r.Timestamp, tgl: r.Tanggal, isi: r.Isi }; });
}
function getSaran(token) {
  return wrap_(function () {
    var u = auth_(token);
    if (u.role === 'teacher') return { ok: true, rows: saran_() };
    return { ok: true, sent: sudahSaran_(u.username) };
  });
}
function deleteSaran(d) {
  return wrap_(function () {
    d = d || {};
    auth_(d.token, 'teacher');
    delRow_('Saran', 0, String(d.ts || ''));
    return { ok: true, rows: saran_(), msg: 'Masukan dihapus.' };
  });
}

/* ---------- Pengingat harian ke Telegram (jadwal besok) ---------- */
// Isi sheet JadwalPelajaran: kolom Hari (Senin..Jumat), Jam (mis. 07.00-08.30), Mapel.
// Token bot & chat id disimpan di Project Settings > Script properties: TG_TOKEN, TG_CHAT.
function pengingatTeks_() {
  var b = new Date(Date.now() + 86400000);
  var tgl = Utilities.formatDate(b, TZ, 'yyyy-MM-dd');
  var hari = HARI[Number(Utilities.formatDate(b, TZ, 'u')) % 7];
  var mp = rows_('JadwalPelajaran').filter(function (r) { return r.Hari === hari; });
  var pk = (JADWAL[hari] || []).map(function (x) { return x[1]; });
  var ag = rows_('Agenda').filter(function (r) { return r.Tanggal === tgl; });
  if (!mp.length && !pk.length && !ag.length) return '';
  var t = '📅 BESOK, ' + hari.toUpperCase() + ' (' + tgl.split('-').reverse().join('/') + ')\nKelas ' + KELAS + '\n';
  if (mp.length) t += '\n📚 Mapel:\n' + mp.map(function (r) { return '• ' + (r.Jam ? r.Jam + '  ' : '') + r.Mapel; }).join('\n') + '\n';
  if (pk.length) t += '\n🧹 Piket:\n' + pk.map(function (n) { return '• ' + n; }).join('\n') + '\n';
  if (ag.length) t += '\n📝 Tugas & agenda:\n' + ag.map(function (r) { return '• [' + r.Jenis + '] ' + r.Judul + (r.Catatan ? ' - ' + r.Catatan : ''); }).join('\n') + '\n';
  return t + '\nSemangat! 💪';
}
function kirimTelegram_(teks) {
  var p = PropertiesService.getScriptProperties(), tok = p.getProperty('TG_TOKEN'), chat = p.getProperty('TG_CHAT');
  if (!tok || !chat) throw new Error('TG_TOKEN / TG_CHAT belum diisi di Script properties.');
  var res = UrlFetchApp.fetch('https://api.telegram.org/bot' + tok + '/sendMessage', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    payload: JSON.stringify({ chat_id: chat, text: teks })
  });
  if (res.getResponseCode() !== 200) throw new Error('Telegram gagal: ' + res.getContentText());
}
function kirimPengingat() {
  var t = pengingatTeks_();
  if (t) kirimTelegram_(t);
}
// Jalankan sekali untuk melihat isi pesan di Log tanpa mengirim
function tesPengingat() { Logger.log(pengingatTeks_() || '(kosong: tidak ada mapel/piket/agenda besok)'); }
// Jalankan sekali setelah bot dimasukkan ke grup & ada 1 pesan di grup: menampilkan chat id di Log
function tgCariChatId() {
  var tok = PropertiesService.getScriptProperties().getProperty('TG_TOKEN');
  Logger.log(UrlFetchApp.fetch('https://api.telegram.org/bot' + tok + '/getUpdates').getContentText());
}
// Jalankan sekali: kirim otomatis tiap hari sekitar jam 17.00-18.00 WIB
function pasangPengingat() {
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'kirimPengingat') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('kirimPengingat').timeBased().everyDays(1).atHour(17).inTimezone(TZ).create();
}

/* ---------- Notifikasi push (Firebase Cloud Messaging) ----------
   Script properties yang dibutuhkan: FCM_SA = seluruh isi file JSON service account Firebase.
   Jalankan sekali: pasangNotif (pasang jadwal otomatis) dan tesNotif (kirim tes ke semua perangkat terdaftar). */
var APP_URL = 'https://abeabe499.github.io/12.8new/';
var BLN_ = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

function daftarPerangkat(d) {
  return wrap_(function () {
    d = d || {};
    var u = auth_(d.token), t = String(d.fcm || '').trim();
    if (t.length < 20) throw new Error('Token notifikasi tidak valid.');
    return withLock_(function () {
      var sh = sheet_('Perangkat'), v = sh.getDataRange().getDisplayValues(), row = 0;
      for (var i = 1; i < v.length; i++) if (v[i][1] === t) { row = i + 1; break; }
      var rec = [String(u.username).toLowerCase(), t, nowInfo_().ts];
      if (row) sh.getRange(row, 1, 1, 3).setValues([rec]); else sh.appendRow(rec);
      return { ok: true };
    });
  });
}

function fcmSA_() {
  var raw = PropertiesService.getScriptProperties().getProperty('FCM_SA');
  if (!raw) throw new Error('FCM_SA belum diisi di Script properties.');
  return JSON.parse(raw);
}
function b64u_(x) { return Utilities.base64EncodeWebSafe(x).replace(/=+$/, ''); }
function fcmAkses_() {
  var cache = CacheService.getScriptCache(), c = cache.get('fcm_at');
  if (c) return c;
  var sa = fcmSA_(), now = Math.floor(Date.now() / 1000);
  var hdr = b64u_(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  var cl = b64u_(JSON.stringify({ iss: sa.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 }));
  var sig = b64u_(Utilities.computeRsaSha256Signature(hdr + '.' + cl, sa.private_key));
  var r = UrlFetchApp.fetch('https://oauth2.googleapis.com/token', {
    method: 'post', muteHttpExceptions: true,
    payload: { grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: hdr + '.' + cl + '.' + sig }
  });
  var j = JSON.parse(r.getContentText());
  if (!j.access_token) throw new Error('Token FCM gagal: ' + r.getContentText());
  cache.put('fcm_at', j.access_token, 3000);
  return j.access_token;
}
// Mengembalikan 'ok', 'hapus' (token sudah tidak berlaku), atau 'gagal'
function fcmKirim_(token, judul, isi) {
  var res = UrlFetchApp.fetch('https://fcm.googleapis.com/v1/projects/' + fcmSA_().project_id + '/messages:send', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: { Authorization: 'Bearer ' + fcmAkses_() },
    payload: JSON.stringify({ message: { token: token, webpush: {
      notification: { title: judul, body: isi, icon: APP_URL + 'icon-192.png' },
      fcm_options: { link: APP_URL }
    } } })
  });
  var code = res.getResponseCode(), body = res.getContentText();
  if (code === 200) return 'ok';
  if (code === 404 || /UNREGISTERED/.test(body)) return 'hapus';
  Logger.log('FCM gagal ' + code + ': ' + body);
  return 'gagal';
}
// pesanPer: { username: [[judul, isi], ...] } -> kirim ke semua perangkat milik username itu
function kirimNotif_(pesanPer) {
  var sh = sheet_('Perangkat'), v = sh.getDataRange().getDisplayValues(), hapus = [], ok = 0;
  for (var i = 1; i < v.length; i++) {
    var L = pesanPer[String(v[i][0]).toLowerCase()];
    if (!L) continue;
    for (var k = 0; k < L.length; k++) {
      var r = fcmKirim_(v[i][1], L[k][0], L[k][1]);
      if (r === 'ok') ok++;
      else if (r === 'hapus') { hapus.push(i + 1); break; }
    }
  }
  hapus.sort(function (a, b) { return b - a; }).forEach(function (b) { sh.deleteRow(b); });
  return ok;
}
function siswaAktif_() { return rows_('Siswa').filter(function (r) { return aktif_(r.Aktif); }); }

// Piket besok (personal) + jadwal pelajaran besok + tugas/PR besok
function pesanHarian_() {
  var b = new Date(Date.now() + 86400000);
  var tgl = Utilities.formatDate(b, TZ, 'yyyy-MM-dd'), hari = HARI[Number(Utilities.formatDate(b, TZ, 'u')) % 7];
  var mp = rows_('JadwalPelajaran').filter(function (r) { return r.Hari === hari; });
  var ag = rows_('Agenda').filter(function (r) { return r.Tanggal === tgl; });
  var pk = {};
  (JADWAL[hari] || []).forEach(function (x) { pk[x[0].toLowerCase()] = 1; });
  var out = {};
  siswaAktif_().forEach(function (s) {
    var un = s.Username.toLowerCase(), L = [];
    if (pk[un]) L.push(['🧹 Besok kamu piket!', 'Hari ' + hari + '. Jangan lupa datang lebih awal dan foto buktinya ya.']);
    if (mp.length) L.push(['📚 Jadwal pelajaran besok (' + hari + ')', mp.map(function (r) { return r.Mapel; }).join(', ')]);
    if (ag.length) L.push(['📝 Tugas & agenda besok', ag.map(function (r) { return r.Judul + (r.Catatan ? ' - ' + r.Catatan : ''); }).join('\n')]);
    if (L.length) out[un] = L;
  });
  return out;
}
function rp_(n) { return 'Rp ' + String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
// Kas: hanya untuk siswa yang masih punya tunggakan sampai bulan berjalan
function pesanKas_() {
  var cur = nowInfo_().tgl.substring(0, 7), by = {}, ms = [], k = KAS_MULAI;
  rows_('Kas').forEach(function (r) {
    var key = kasKey_(Number(r.Tahun), Number(r.Bulan)), un = r.Username.toLowerCase();
    (by[un] = by[un] || {})[key] = Number(r.NominalBayar) || 0;
  });
  while (k <= cur) { ms.push(k); k = kasNext_(k); }
  var out = {};
  siswaAktif_().forEach(function (s) {
    var un = s.Username.toLowerCase(), ar = 0, kur = [];
    ms.forEach(function (m) { var b = (by[un] || {})[m] || 0; if (b < IURAN) { ar += IURAN - b; kur.push(BLN_[+m.slice(5) - 1]); } });
    if (ar > 0) out[un] = [['💰 Uang kas belum lunas', 'Kas kamu masih kurang ' + rp_(ar) + ' (' + kur.join(', ') + '). Yuk dilunasi ke bendahara.']];
  });
  return out;
}
function kirimNotifHarian() { Logger.log('Terkirim: ' + kirimNotif_(pesanHarian_())); }
function kirimNotifKas() { Logger.log('Terkirim: ' + kirimNotif_(pesanKas_())); }
// Jalankan sekali: harian jam 17.00 WIB, kas tiap Senin jam 07.00 WIB
function pasangNotif() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    var f = t.getHandlerFunction();
    if (f === 'kirimNotifHarian' || f === 'kirimNotifKas') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('kirimNotifHarian').timeBased().everyDays(1).atHour(17).inTimezone(TZ).create();
  ScriptApp.newTrigger('kirimNotifKas').timeBased().onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(7).inTimezone(TZ).create();
}
// Kirim notifikasi tes ke semua perangkat yang sudah terdaftar
function tesNotif() {
  var v = sheet_('Perangkat').getDataRange().getDisplayValues(), p = {};
  for (var i = 1; i < v.length; i++) p[String(v[i][0]).toLowerCase()] = [['🔔 Tes notifikasi', 'Kalau ini muncul, notifikasi kelas 12.8 sudah jalan.']];
  Logger.log('Terkirim: ' + kirimNotif_(p));
}
// Lihat isi pesan tanpa mengirim
function tesIsiNotif() { Logger.log(JSON.stringify(pesanHarian_()).substring(0, 1500) + '\n' + JSON.stringify(pesanKas_()).substring(0, 1500)); }

/* ---------- Jadwal pelajaran awal (urutan = urutan jam pelajaran/JP) ---------- */
var MAPEL = {
  Senin: [['Matematika', 2], ['Sosiologi', 2], ['Ekonomi', 2], ['Geografi', 3]],
  Selasa: [['Sejarah', 2], ['PKWU', 2], ['Informatika', 2], ['PPKn', 2], ['Seni Rupa', 2]],
  Rabu: [['PAI', 3], ['B. Sunda', 2], ['Matematika', 2], ['Ekonomi', 3]],
  Kamis: [['B. Indonesia', 2], ['Geografi', 2], ['PJOK', 3], ['Informatika', 3]],
  Jumat: [['B. Inggris', 3], ['Sosiologi', 3], ['BK', 1], ['B. Indonesia', 2]]
};
// Jalankan sekali: mengisi sheet JadwalPelajaran (hanya jika masih kosong)
function isiJadwalPelajaran() {
  var sh = sheet_('JadwalPelajaran');
  if (sh.getLastRow() > 1) return 'Sheet JadwalPelajaran sudah berisi, tidak diubah.';
  var out = [];
  ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat'].forEach(function (d) {
    var n = 1;
    MAPEL[d].forEach(function (m) {
      var a = n, b = n + m[1] - 1;
      out.push([d, m[1] === 1 ? 'JP ' + a : 'JP ' + a + '-' + b, m[0]]);
      n = b + 1;
    });
  });
  sh.getRange(2, 1, out.length, 3).setValues(out);
  return 'Terisi ' + out.length + ' baris.';
}

// Untuk membuat ulang data awal dari laporan: hanya menghapus baris "Data awal" yang BELUM diedit bendahara, lalu mengisi lagi
function ulangKasAwal() {
  var sh = sheet_('Kas'), v = sh.getDataRange().getDisplayValues();
  for (var i = v.length - 1; i >= 1; i--) if (v[i][12] === 'Data awal') sh.deleteRow(i + 1);
  return isiKasAwal();
}

/* ---------- Pengeluaran kas (dicatat bendahara, terlihat semua siswa) ---------- */
function kasKeluar_() {
  var v = rows_('KasKeluar'), tot = 0;
  v.forEach(function (r) { if (r.Status !== 'Batal') tot += Number(r.Jumlah) || 0; });
  var list = v.slice().sort(function (a, b) { return (a.Tanggal + a.UpdatedAt) < (b.Tanggal + b.UpdatedAt) ? 1 : -1; }).slice(0, 150)
    .map(function (r) { return { id: r.ID, tgl: r.Tanggal, hal: r.Keperluan, jml: Number(r.Jumlah) || 0, cat: r.Catatan, st: r.Status, oleh: r.Oleh, kat: r.Kategori || 'Lainnya' }; });
  return { total: tot, list: list };
}
function addCashExpense(d) {
  return wrap_(function () {
    d = d || {};
    var u = authBendahara_(d.token), n = nowInfo_();
    var KAT = ['Alat tulis', 'Kebersihan', 'Acara', 'Konsumsi', 'Perlengkapan', 'Sosial', 'Lainnya'], kat = KAT.indexOf(String(d.kat)) >= 0 ? String(d.kat) : 'Lainnya';
    var hal = String(d.hal || '').trim().substring(0, 80), jml = Math.round(Number(d.jml)), cat = String(d.cat || '').trim().substring(0, 200);
    var tgl = /^\d{4}-\d{2}-\d{2}$/.test(String(d.tgl || '')) ? String(d.tgl) : n.tgl;
    if (!hal) throw new Error('Keperluan wajib diisi.');
    if (!(jml > 0 && jml <= 10000000)) throw new Error('Jumlah tidak valid.');
    withLock_(function () {
      var paid = 0;
      rows_('Kas').forEach(function (r) { paid += Number(r.NominalBayar) || 0; });
      if (jml > paid - kasKeluar_().total) throw new Error('Pengeluaran melebihi saldo kas.');
      sheet_('KasKeluar').appendRow([n.ts + '#' + Math.floor(Math.random() * 1000), tgl, hal, jml, cat, 'Aktif', u.nama, n.ts, kat]);
    });
    var r = exploreData_(u); r.msg = 'Pengeluaran dicatat.'; return r;
  });
}
// Pengeluaran tidak dihapus, hanya ditandai Batal supaya jejaknya tetap terlihat
function cancelCashExpense(d) {
  return wrap_(function () {
    d = d || {};
    var u = authBendahara_(d.token), n = nowInfo_();
    withLock_(function () {
      var sh = sheet_('KasKeluar'), v = sh.getDataRange().getDisplayValues(), ok = false;
      for (var i = 1; i < v.length; i++) {
        if (v[i][0] === String(d.id || '')) {
          sh.getRange(i + 1, 6).setValue('Batal');
          sh.getRange(i + 1, 8).setValue(n.ts + ' (dibatalkan ' + u.nama + ')');
          ok = true; break;
        }
      }
      if (!ok) throw new Error('Data tidak ditemukan.');
    });
    var r = exploreData_(u); r.msg = 'Pengeluaran dibatalkan.'; return r;
  });
}
